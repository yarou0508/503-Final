library(shiny)

# Read in dataset
h1b <- read.csv('data//h1b_2016_computer_certified.csv')

# Define UI for application that draws a histogram
shinyUI(fluidPage(
  
  # Application title
  titlePanel("Annual Salary of H1B Certified Records"),
  
  # Sidebar with a slider input for number of bins 
  sidebarLayout(
    sidebarPanel(
       sliderInput("bins",
                   "Number of bins:",
                   min = 30,
                   max = 100,
                   value = 50),
       selectInput("choice","Choice:",
                   choices = colnames(h1b)),
       hr(),
       helpText("2016 H1B Data from Kaggle."),
       width = 3
    ),
    
    # Show a plot of the generated distribution
    mainPanel(column(6,plotOutput(outputId="distPlot1", width="450px",height="400px")),
              column(6,plotOutput(outputId="distPlot2", width="450px",height="400px")),
       plotOutput("scatterPlot")
    )
  )
))
