library(shiny)

# Read in dataset
#setwd("C:/Users/47532/Desktop/503Visualization/Final Exam/Shiny-503")
h1b <- read.csv('data//h1b_2016_computer_certified.csv')
# Define server logic required to draw a histogram
shinyServer(function(input, output) {
  output$scatterPlot <- renderPlot({
    # Tender a scatterplot
    plot(h1b[,input$choice], h1b$PREVAILING_WAGE, col = 'blue', pch = 18,
         main=input$choice,
         ylab="Annual Prevailing Wage",
         xlab= input$choice)
  })
  output$distPlot1 <- renderPlot({
    
    # generate bins based on input$bins from ui.R
    Annual_Salary    <- h1b$ACTUAL_ANNUAL_SALARY
    bins <- seq(min(Annual_Salary), max(Annual_Salary), length.out = input$bins + 1)
    
    # draw the histogram with the specified number of bins
    return(hist(Annual_Salary, breaks = bins, col = 'purple', border = 'white'))
    
  })
  output$distPlot2 <- renderPlot({
    
    # generate bins based on input$bins from ui.R
    Annual_Prevailing_Wage <- h1b$PREVAILING_WAGE 
    bins <- seq(min(Annual_Prevailing_Wage), max(Annual_Prevailing_Wage), length.out = input$bins + 1)
    
    # draw the histogram with the specified number of bins
    return(hist(Annual_Prevailing_Wage, breaks = bins, col = 'orange', border = 'white'))
    
  })
  
})
